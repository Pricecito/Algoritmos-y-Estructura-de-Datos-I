﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio10_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void mostrarPadre(Padre p)
        {
            txaRes.Clear();
            String msj = p.verMensaje();
            txaRes.AppendText(msj + "\n");
            txaRes.AppendText("     NOMBRE: " + p.getNombre() + "\n");
            txaRes.AppendText("     EDAD: " + p.getEdad() + "\n");
            txaRes.AppendText("     SUELDO: " + p.getSueldo() + "\n");
        }

        public void mostrarHija(Hija h)
        {
            txaRes.Clear();
            String msj = h.verMensaje();
            txaRes.AppendText(msj + "\n");
            txaRes.AppendText("     NOMBRE: " + h.getNombre() + "\n");
            txaRes.AppendText("     EDAD: " + h.getEdad() + "\n");
            txaRes.AppendText("     SUELDO: " + h.getSueldo() + "\n");
            txaRes.AppendText("     CARRERA: " + h.getCarrera() + "\n");
        }

        public void mostrarNieta(Nieta n)
        {
            String msj = n.verMensaje();
            txaRes.AppendText(msj + "\n");
            txaRes.AppendText("     NOMBRE: " + n.getNombre() + "\n");
            txaRes.AppendText("     EDAD: " + n.getEdad() + "\n");
            txaRes.AppendText("     MUSICA: " + n.getMusica() + "\n");
        }

        private void btnPadre_Click(object sender, EventArgs e)
        {
            Padre Padre1 = new Padre("Padre 1", 50, 1500);
            mostrarPadre(Padre1);
        }

        private void btnHija_Click(object sender, EventArgs e)
        {
            Hija Hija1 = new Hija("Hija 1", 26, 500, "Sistemas");
            mostrarHija(Hija1);
        }

        private void btnNieta_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Nieta Nieta1 = new Nieta("Nieta 1", 10, "POP");
            mostrarNieta(Nieta1);
            MessageBox.Show(this, "NIETA CUMPLE AÑOS","INFORMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Nieta1.cumplirAños();
            mostrarNieta(Nieta1);
        }
    }
}
