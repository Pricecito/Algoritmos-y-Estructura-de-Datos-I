﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10_2
{
    public class Padre
    {
        protected String nombre;
        protected int edad;
        protected double sueldo;

        public Padre(String nombre, int edad)
        {
            this.nombre = nombre;
            this.edad = edad;
        }

        public Padre(String nombre, int edad, double sueldo)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.sueldo = sueldo;
        }

        public void setNombre(String nom)
        { this.nombre = nom; }

        public void setEdad(int e)
        { this.edad = e; }

        public void setSueldo(double s)
        { this.sueldo = s; }

        public String getNombre()
        { return nombre; }

        public int getEdad()
        { return edad; }

        public double getSueldo()
        { return sueldo; }

        public void cumplirAños()
        { this.edad++; }

        public virtual String verMensaje()
        { return "OBJETO DE LA CLASE PADRE"; }
    }
}
