﻿
namespace Ejercicio10_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPadre = new System.Windows.Forms.Button();
            this.btnHija = new System.Windows.Forms.Button();
            this.btnNieta = new System.Windows.Forms.Button();
            this.txaRes = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnPadre
            // 
            this.btnPadre.Location = new System.Drawing.Point(3, 2);
            this.btnPadre.Name = "btnPadre";
            this.btnPadre.Size = new System.Drawing.Size(334, 23);
            this.btnPadre.TabIndex = 0;
            this.btnPadre.Text = "PADRE";
            this.btnPadre.UseVisualStyleBackColor = true;
            this.btnPadre.Click += new System.EventHandler(this.btnPadre_Click);
            // 
            // btnHija
            // 
            this.btnHija.Location = new System.Drawing.Point(3, 32);
            this.btnHija.Name = "btnHija";
            this.btnHija.Size = new System.Drawing.Size(334, 23);
            this.btnHija.TabIndex = 1;
            this.btnHija.Text = "HIJA";
            this.btnHija.UseVisualStyleBackColor = true;
            this.btnHija.Click += new System.EventHandler(this.btnHija_Click);
            // 
            // btnNieta
            // 
            this.btnNieta.Location = new System.Drawing.Point(3, 62);
            this.btnNieta.Name = "btnNieta";
            this.btnNieta.Size = new System.Drawing.Size(334, 23);
            this.btnNieta.TabIndex = 2;
            this.btnNieta.Text = "NIETA";
            this.btnNieta.UseVisualStyleBackColor = true;
            this.btnNieta.Click += new System.EventHandler(this.btnNieta_Click);
            // 
            // txaRes
            // 
            this.txaRes.Location = new System.Drawing.Point(3, 92);
            this.txaRes.Name = "txaRes";
            this.txaRes.Size = new System.Drawing.Size(334, 193);
            this.txaRes.TabIndex = 3;
            this.txaRes.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 292);
            this.Controls.Add(this.txaRes);
            this.Controls.Add(this.btnNieta);
            this.Controls.Add(this.btnHija);
            this.Controls.Add(this.btnPadre);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ejercicio10-2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPadre;
        private System.Windows.Forms.Button btnHija;
        private System.Windows.Forms.Button btnNieta;
        private System.Windows.Forms.RichTextBox txaRes;
    }
}

