﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10_2
{
    public class Hija : Padre
    {
        protected String carrera;

        public Hija(String nombre, int edad): base(nombre, edad)
        {}

        public Hija(String nombre, int edad, double sueldo, String carrera) : base(nombre, edad, sueldo)
        {
            this.carrera = carrera;
        }

        public void setCarrera(String carrera)
        { this.carrera = carrera; }

        public String getCarrera()
        { return carrera; }

        public override String verMensaje()
        { return "OBJETO DE LA CLASE HIJA"; }
    }
}
