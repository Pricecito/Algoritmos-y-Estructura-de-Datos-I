﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10_2
{
    public class Nieta : Hija
    {
        private String musica;

        public Nieta(String nombre, int edad, String musica) : base(nombre, edad)
        {
            this.musica = musica;
        }

        public void setMusica(String musica)
        { this.musica = musica; }

        public String getMusica()
        { return musica; }

        public override String verMensaje()
        { return "OBJETO DE LA CLASE NIETA"; }
    }
}
