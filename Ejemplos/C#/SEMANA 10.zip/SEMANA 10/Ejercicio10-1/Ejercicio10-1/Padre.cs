﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10_1
{
    public class Padre
    {
        protected String nombre;
        protected int edad;
        protected float sueldo;

        public Padre()
        {
            this.nombre = "XXX";
        }

        public Padre(String nom)
        {
            this.nombre = nom;
        }

        public Padre(String nombre, int edad, float sueldo)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.sueldo = sueldo;
        }

        //metodos set
        public void setNombre(String nombre)
        {
            this.nombre = nombre;
        }

        public void setEdad(int edad)
        {
            if (edad > 0)
                this.edad = edad;
        }

        public void setSueldo(float sueldo)
        {
            this.sueldo = sueldo;
        }

        //metodos get
        public String getNombre()
        {
            return nombre;
        }

        public int getEdad()
        {
            return edad;
        }

        public float getSueldo()
        {
            return sueldo;
        }

        public virtual String verMensaje()
        {
            return "OBJETO DE LA CLASE PADRE";
        }
    }
}
