﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio10_1
{
    public class Hija : Padre
    {
        private String carrera;

        public Hija() //MUCHO CUIDADO
        {
            this.carrera = "NINGUNA";
        }

        public Hija(String nombre, int edad, float sueldo, String carrera): base(nombre, edad, sueldo)
        {
            this.carrera = carrera;
        }

        public Hija(String nombre, String carrera):base(nombre)
        {
            this.carrera = carrera;
        }

        public void setCarrera(String carrera)
        {
            this.carrera = carrera;
        }

        public String getCarrera()
        {
            return carrera;
        }

        public override String verMensaje()
        {
            return "OBJETO DE LA CLASE HIJA";
        }
    }
}
