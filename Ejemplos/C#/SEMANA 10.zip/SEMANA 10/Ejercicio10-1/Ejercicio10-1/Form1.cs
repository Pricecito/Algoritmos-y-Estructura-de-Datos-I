﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio10_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void mostrarPadre(Padre p)
        {
            String msj = p.verMensaje();
            txaRes.AppendText(msj + "\n");
            txaRes.AppendText("     NOMBRE: " + p.getNombre() + "\n");
            txaRes.AppendText("     EDAD: " + p.getEdad() + "\n");
            txaRes.AppendText("     SUELDO: " + p.getSueldo() + "\n");
        }

        public void mostrarHija(Hija h)
        {
            String msj = h.verMensaje();
            txaRes.AppendText(msj + "\n");
            txaRes.AppendText("     NOMBRE: " + h.getNombre() + "\n");
            txaRes.AppendText("     EDAD: " + h.getEdad() + "\n");
            txaRes.AppendText("     SUELDO: " + h.getSueldo() + "\n");
            txaRes.AppendText("     CARRERA: " + h.getCarrera() + "\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Padre padre1 = new Padre();
            mostrarPadre(padre1);
            Padre padre2 = new Padre("Juan", 45, 1000);
            mostrarPadre(padre2);
        }

        private void btnHija_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Hija hija1 = new Hija();
            mostrarHija(hija1);
            Hija hija2 = new Hija("Maria", 18, 500, "Sistemas");
            mostrarHija(hija2);
            Hija hija3 = new Hija("Juana", "Industrial");
            mostrarHija(hija3);
        }
    }
}
