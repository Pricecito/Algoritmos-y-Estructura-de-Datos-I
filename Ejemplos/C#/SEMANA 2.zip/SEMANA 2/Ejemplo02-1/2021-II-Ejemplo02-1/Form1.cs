﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2021_II_Ejemplo02_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double ing, cc, c_inicial, resto, c_mensual;
            ing = Double.Parse(txtIngresos.Text);
            cc = Double.Parse(txtCostoCasa.Text);
            if (ing < 2000)
            {
                c_inicial = cc * 0.15;
                resto = cc - c_inicial;
                c_mensual = resto / 120;
            }
            else
            {
                c_inicial = cc * 0.30;
                resto = cc - c_inicial;
                c_mensual = resto / 84;
            }
            txaRes.Clear();
            txaRes.AppendText("CUOTA INICiAL: " + c_inicial + "\n");
            txaRes.AppendText("CUOTA MENSUAL: " + c_mensual + "\n");
        }
    }
}