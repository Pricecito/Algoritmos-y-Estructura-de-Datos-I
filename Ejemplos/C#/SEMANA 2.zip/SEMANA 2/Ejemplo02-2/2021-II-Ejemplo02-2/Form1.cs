﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace _2021_II_Ejemplo02_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngreso_Click(object sender, EventArgs e)
        {
            int edad, c_personas=0, c_hombres=0, c_mujeres = 0;
            int suma_eh=0, suma_em = 0, menor = 999;
            String sexo;
            txaRes.Clear();
            do
            {
                edad = int.Parse(Interaction.InputBox("INGRESE EDAD", "INGRESAR"));
                if (edad >= 18)
                {
                    sexo = Interaction.InputBox("INGRESE SEXO", "INGRESAR").ToUpper();

                    c_personas = c_personas + 1;

                    if (sexo=="M")
                    {
                        c_hombres = c_hombres + 1;
                        suma_eh = suma_eh + edad;
                    }
                    else
                    {
                        c_mujeres = c_mujeres + 1;
                        suma_em = suma_em + edad;
                    }

                    if (edad < menor)
                        menor = edad;

                    txaRes.AppendText(edad + " --- " + sexo + "\n");
                }
                else if (edad != 0)
                    MessageBox.Show(this, "NO INGRESA - MENOR DE EDAD!!!",
                    "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } while (edad != 0);
            
            txaRes.AppendText("PERSONAS EN LA FIESTA: " + c_personas + "\n");
            txaRes.AppendText("HOMBRES EN LA FIESTA: " + c_hombres + "\n");
            txaRes.AppendText("MUJERES EN LA FIESTA: " + c_mujeres + "\n");
            txaRes.AppendText("PROMEDIO DE EDAD HOMBRES: " + (suma_eh / c_hombres) + "\n");
            txaRes.AppendText("PROMEDIO DE EDAD MUJERES: " + (suma_em / c_mujeres) + "\n");
            txaRes.AppendText("PERSONA MAS JOVEN EN LA FIESTA: " + menor + "\n");
        }
    }
}
