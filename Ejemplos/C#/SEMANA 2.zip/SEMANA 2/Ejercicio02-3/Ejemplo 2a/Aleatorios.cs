﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejemplo_2a
{
    public partial class Aleatorios : Form
    {
        int numeroAleatorio;
        public Aleatorios()
        {
            InitializeComponent();
		}

       

		public void mostrarAleatorios()
		{
			int cantidad;
			int i = 1;

			cantidad = int.Parse(txtCantidadAleatorios.Text);

			txaRes.Clear();

			while (i <= cantidad)
			{
				generarAleatorio();
				txaRes.AppendText(numeroAleatorio+"\n");
				i++;
			}
		}

		public void generarAleatorio()
		{
			Random rand = new Random();
			numeroAleatorio = rand.Next(100);
		}

        private void btnGenerar_Click(object sender, EventArgs e)
        {
			mostrarAleatorios();
		}
    }
}
