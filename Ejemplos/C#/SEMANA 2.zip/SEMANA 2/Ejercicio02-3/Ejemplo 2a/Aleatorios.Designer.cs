﻿
namespace Ejemplo_2a
{
    partial class Aleatorios
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtCantidadAleatorios = new System.Windows.Forms.TextBox();
            this.btnGenerar = new System.Windows.Forms.Button();
            this.txaRes = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(227, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cantidad de numeros aleatorios a generar";
            // 
            // txtCantidadAleatorios
            // 
            this.txtCantidadAleatorios.Location = new System.Drawing.Point(245, 24);
            this.txtCantidadAleatorios.Name = "txtCantidadAleatorios";
            this.txtCantidadAleatorios.Size = new System.Drawing.Size(100, 23);
            this.txtCantidadAleatorios.TabIndex = 1;
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(12, 56);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(333, 23);
            this.btnGenerar.TabIndex = 2;
            this.btnGenerar.Text = "Generar Aleatorios";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // txaRes
            // 
            this.txaRes.Location = new System.Drawing.Point(13, 86);
            this.txaRes.Name = "txaRes";
            this.txaRes.Size = new System.Drawing.Size(331, 143);
            this.txaRes.TabIndex = 3;
            this.txaRes.Text = "";
            // 
            // Aleatorios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 241);
            this.Controls.Add(this.txaRes);
            this.Controls.Add(this.btnGenerar);
            this.Controls.Add(this.txtCantidadAleatorios);
            this.Controls.Add(this.label1);
            this.Name = "Aleatorios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EJERCICIO02-3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCantidadAleatorios;
        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.RichTextBox txaRes;
    }
}

