﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4_5
{
    public partial class Form1 : Form
    {
        int[] numeros;
        int indice;
        public Form1()
        {
            InitializeComponent();
            numeros = new int[4];
            indice = 0;
        }

        public void Agregar(int num)
        {
            if (indice < numeros.Length)
            {
                numeros[indice] = num;
                indice++;
            }
            else
                MessageBox.Show(this, "VECTOR LLENO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        public void Mostrar()
        {
            for (int i = 0; i < indice; i++)
            {
                txtMostrar.AppendText("POS [" + i.ToString() + "]--> " + numeros[i].ToString() + "\r\n");
            }
        }

        public int Buscar(int nbus)
        {
            int pos = -1;
            for (int i = 0; i < indice; i++)
            {
                if (numeros[i] == nbus) 
                { 
                    pos = i;
                }
            }
            return pos;
        }

        public void Modificar(int pos, int vmod)
        {
            numeros[pos] = vmod;
            MessageBox.Show(this, "VALOR MODIFICADO",
                "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            String tex = txtNum.Text;
            if (tex != "")
            {
                int numero = int.Parse(txtNum.Text);
                Agregar(numero);
            }
            else
                MessageBox.Show(this, "NO INGRESO NINGUN DATO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtNum.Text=null;
            txtNum.Focus();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            //double par=0, imp=0;
            txtMostrar.Text=null;
            Mostrar();
 
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int nbus = int.Parse(txtBus.Text);
            int pos = Buscar(nbus);
            if (pos != -1)
                MessageBox.Show(this, "VALOR ENCONTRADO EN LA POSICIÓN: " + pos,
                "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(this, "NO SE ENCONTRO NINGUN VALOR",
                "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            int nbus = int.Parse(txtBus.Text);
            int nmod = int.Parse(txtMod.Text);
            int pos = Buscar(nbus);
            if (pos != -1)
                Modificar(pos, nmod);
            else
                MessageBox.Show(this, "NO SE PUEDE MODIFICAR, NO SE ENCONTRO NINGUN VALOR",
                "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtBus.Text=null;
            txtMod.Text=null;
        }
    }
}
