﻿
namespace Ejercicio5_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.RegistrarNom = new System.Windows.Forms.Button();
            this.MostrarNom = new System.Windows.Forms.Button();
            this.BuscarNom = new System.Windows.Forms.Button();
            this.NomConsonantes = new System.Windows.Forms.Button();
            this.txtRes = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "NOMBRE";
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(95, 5);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(100, 23);
            this.txtNom.TabIndex = 1;
            // 
            // RegistrarNom
            // 
            this.RegistrarNom.Location = new System.Drawing.Point(10, 36);
            this.RegistrarNom.Name = "RegistrarNom";
            this.RegistrarNom.Size = new System.Drawing.Size(185, 23);
            this.RegistrarNom.TabIndex = 2;
            this.RegistrarNom.Text = "Registrar Nombre";
            this.RegistrarNom.UseVisualStyleBackColor = true;
            this.RegistrarNom.Click += new System.EventHandler(this.RegistrarNom_Click);
            // 
            // MostrarNom
            // 
            this.MostrarNom.Location = new System.Drawing.Point(10, 65);
            this.MostrarNom.Name = "MostrarNom";
            this.MostrarNom.Size = new System.Drawing.Size(185, 23);
            this.MostrarNom.TabIndex = 3;
            this.MostrarNom.Text = "Mostrar Nombres";
            this.MostrarNom.UseVisualStyleBackColor = true;
            this.MostrarNom.Click += new System.EventHandler(this.MostrarNom_Click);
            // 
            // BuscarNom
            // 
            this.BuscarNom.Location = new System.Drawing.Point(10, 96);
            this.BuscarNom.Name = "BuscarNom";
            this.BuscarNom.Size = new System.Drawing.Size(185, 23);
            this.BuscarNom.TabIndex = 4;
            this.BuscarNom.Text = "Buscar Nombre";
            this.BuscarNom.UseVisualStyleBackColor = true;
            this.BuscarNom.Click += new System.EventHandler(this.BuscarNom_Click);
            // 
            // NomConsonantes
            // 
            this.NomConsonantes.Location = new System.Drawing.Point(10, 125);
            this.NomConsonantes.Name = "NomConsonantes";
            this.NomConsonantes.Size = new System.Drawing.Size(185, 23);
            this.NomConsonantes.TabIndex = 5;
            this.NomConsonantes.Text = "Nombres con Cant. Conson.";
            this.NomConsonantes.UseVisualStyleBackColor = true;
            this.NomConsonantes.Click += new System.EventHandler(this.NomConsonantes_Click);
            // 
            // txtRes
            // 
            this.txtRes.Location = new System.Drawing.Point(12, 163);
            this.txtRes.Multiline = true;
            this.txtRes.Name = "txtRes";
            this.txtRes.Size = new System.Drawing.Size(183, 200);
            this.txtRes.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(206, 368);
            this.Controls.Add(this.txtRes);
            this.Controls.Add(this.NomConsonantes);
            this.Controls.Add(this.BuscarNom);
            this.Controls.Add(this.MostrarNom);
            this.Controls.Add(this.RegistrarNom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Listado de Nombres";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.Button RegistrarNom;
        private System.Windows.Forms.Button MostrarNom;
        private System.Windows.Forms.Button BuscarNom;
        private System.Windows.Forms.Button NomConsonantes;
        private System.Windows.Forms.TextBox txtRes;
    }
}

