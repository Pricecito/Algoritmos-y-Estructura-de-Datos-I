﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejercicio5_1
{
    public partial class Form1 : Form
    {
        String[] nombre;
        int indice;
        public Form1()
        {
            InitializeComponent();
            nombre = new String[4];
            indice = 0;
        }

        public void registrarNombre()
        {
            if (indice < nombre.Length)
            {
                nombre[indice] = txtNom.Text;
                indice++;
            }
            else
                MessageBox.Show(this, "VECTOR LLENO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void mostrarNombres()
        {
            for (int i = 0; i < indice; i++)
            {
                txtRes.AppendText("POS [" + i + "]--> " + nombre[i].ToString() + "\r\n");
            }
        }

        public int buscarNombre(String nbus)
        {
            int pos = -1;
            for (int i = 0; i < indice; i++)
            {
                if (nombre[i]==nbus)
                    pos = i;
            }
            return pos;
        }

        public void mostrarNombresConsonantes()
        {
            for (int i = 0; i < indice; i++)
            {
                int can = obtenerCantidadConsonantes(nombre[i].ToLower());
                txtRes.AppendText(nombre[i] + " " + can + " consonantes \r\n");
            }
        }

        public int obtenerCantidadConsonantes(String nm)
        {
            int cant = 0;
            for (int i = 0; i < nm.Length; i++)
            {
                if (nm[i] != 'a' && nm[i] != 'e' && nm[i] != 'i' && nm[i] != 'o' && nm[i] != 'u')
                    cant++;
            }
            return cant;
        }

        private void RegistrarNom_Click(object sender, EventArgs e)
        {
            registrarNombre();
            txtNom.Text=null;
            txtNom.Focus();
        }

        private void MostrarNom_Click(object sender, EventArgs e)
        {
            txtRes.Text=null;
            mostrarNombres();
        }

        private void BuscarNom_Click(object sender, EventArgs e)
        {
            String nbus = Interaction.InputBox("DATO", "INGRESAR DATOS");
            int pos = buscarNombre(nbus);
            if (pos != -1)
                MessageBox.Show(this, "VALOR ENCONTRADO EN LA POSICIÓN: " + pos,
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show(this, "NO SE ENCONTRO NINGUN VALOR",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void NomConsonantes_Click(object sender, EventArgs e)
        {
            txtRes.Text=null;
            mostrarNombresConsonantes();
        }
    }
}
