﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejercicio5_3
{
    public partial class Form1 : Form
    {
        double[] vPromedioAlumno;
        int indice;
        public Form1()
        {
            InitializeComponent();
            int dato = int.Parse(Interaction.InputBox("DATO", "INGRESAR DATOS"));
            vPromedioAlumno = new double[dato];
            indice = 0;
        }

        public char validarPromedioAlumno(double num)
        {
            char ch = 'n';
            if (num >= 0 && num <= 20)
                ch = 's';

            return ch;
        }

        public double redondearDecimales(double num)
        {
            return Math.Round(num,2);
        }

        public double calcularPromedio()
        {
            double prom, sum = 0, c = 0;
            for (int i = 0; i < indice; i++)
            {
                sum = sum + vPromedioAlumno[i];
                c++;
            }
            prom = sum / c;
            return prom;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            String tex = txtReg.Text;
            if (tex != "")
            {
                if (indice < vPromedioAlumno.Length)
                {
                    double num = Double.Parse(txtReg.Text);
                    char op = validarPromedioAlumno(num);
                    if (op == 's')
                    {
                        vPromedioAlumno[indice] = redondearDecimales(num);
                        indice++;
                    }
                    else
                        MessageBox.Show(this, "Promedio No Valido",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show(this, "VECTOR LLENO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show(this, "NO INGRESO NINGUN DATO",
                "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtReg.Text="";
            txtReg.Focus();

        }

        private void btListarNotas_Click(object sender, EventArgs e)
        {
            txtRes.Text="";
            if (indice != 0)
            {
                for (int i = 0; i < indice; i++)
                {
                    txtRes.AppendText(i + " ----------> " + vPromedioAlumno[i].ToString() + "\r\n");
                }
            }
            else
                MessageBox.Show(this, "No hay datos para listar",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void CalcularPromedio_Click(object sender, EventArgs e)
        {
            double prom;
            if (indice == vPromedioAlumno.Length)
            {
                prom = redondearDecimales(calcularPromedio());
                MessageBox.Show(this, "PROMEDIO DEL AULA: " + prom,
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show(this, "NO SE PUEDE CALCULAR EL PROMEDIO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
