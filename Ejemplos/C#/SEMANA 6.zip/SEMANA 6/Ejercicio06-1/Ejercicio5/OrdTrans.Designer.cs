﻿
namespace Ejercicio5
{
    partial class OrdTrans
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGenerar = new System.Windows.Forms.Button();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.btnOrdenarAsc = new System.Windows.Forms.Button();
            this.btnBurbujaAsc = new System.Windows.Forms.Button();
            this.txaMostrar = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnGenerar
            // 
            this.btnGenerar.Location = new System.Drawing.Point(12, 11);
            this.btnGenerar.Name = "btnGenerar";
            this.btnGenerar.Size = new System.Drawing.Size(138, 23);
            this.btnGenerar.TabIndex = 0;
            this.btnGenerar.Text = "GENERAR";
            this.btnGenerar.UseVisualStyleBackColor = true;
            this.btnGenerar.Click += new System.EventHandler(this.btnGenerar_Click);
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(12, 40);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(138, 23);
            this.btnMostrar.TabIndex = 1;
            this.btnMostrar.Text = "MOSTRAR";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // btnOrdenarAsc
            // 
            this.btnOrdenarAsc.Location = new System.Drawing.Point(12, 99);
            this.btnOrdenarAsc.Name = "btnOrdenarAsc";
            this.btnOrdenarAsc.Size = new System.Drawing.Size(138, 23);
            this.btnOrdenarAsc.TabIndex = 2;
            this.btnOrdenarAsc.Text = "ORDENAR ASC";
            this.btnOrdenarAsc.UseVisualStyleBackColor = true;
            this.btnOrdenarAsc.Click += new System.EventHandler(this.btnOrdenarAsc_Click);
            // 
            // btnBurbujaAsc
            // 
            this.btnBurbujaAsc.Location = new System.Drawing.Point(12, 70);
            this.btnBurbujaAsc.Name = "btnBurbujaAsc";
            this.btnBurbujaAsc.Size = new System.Drawing.Size(138, 23);
            this.btnBurbujaAsc.TabIndex = 5;
            this.btnBurbujaAsc.Text = "BURBUJA ASC";
            this.btnBurbujaAsc.UseVisualStyleBackColor = true;
            this.btnBurbujaAsc.Click += new System.EventHandler(this.btnBurbujaAsc_Click);
            // 
            // txaMostrar
            // 
            this.txaMostrar.Location = new System.Drawing.Point(157, 11);
            this.txaMostrar.Name = "txaMostrar";
            this.txaMostrar.Size = new System.Drawing.Size(137, 200);
            this.txaMostrar.TabIndex = 6;
            this.txaMostrar.Text = "";
            // 
            // OrdTrans
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 223);
            this.Controls.Add(this.txaMostrar);
            this.Controls.Add(this.btnBurbujaAsc);
            this.Controls.Add(this.btnOrdenarAsc);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnGenerar);
            this.Name = "OrdTrans";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ORDENAR";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGenerar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnOrdenarAsc;
        private System.Windows.Forms.Button btnBurbujaAsc;
        private System.Windows.Forms.RichTextBox txaMostrar;
    }
}

