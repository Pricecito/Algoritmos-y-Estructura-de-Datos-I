﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejercicio5
{
    public partial class OrdTrans : Form
    {
        int[] numeros;
        int indice;
        public OrdTrans()
        {
            InitializeComponent();
        }

        public void Agregar()
        {
            Random rnd = new Random();
            for (int i = 0; i < numeros.Length; i++)
            {
                numeros[i] = rnd.Next(0,1000);
                indice++;
            }
        }

        public void Mostrar()
        {
            for (int i = 0; i < indice; i++)
            {
                txaMostrar.AppendText("POS [" + i + "]--> " + numeros[i].ToString() + "\n");
            }
        }

        public void InsercionAsc()
        {
            int aux, j;
            for (int p = 1; p < numeros.Length; p++)
            {
                aux = numeros[p];
                j = p - 1;
                while ((j >= 0) && (aux < numeros[j]))
                {
                    numeros[j + 1] = numeros[j];
                    j--;
                }
                numeros[j + 1] = aux;
            }
        }

        public void BurbujaAsc()
        {
            int aux;
            for (int i = 0; i < numeros.Length - 1; i++)
            {
                for (int j = i+1; j < numeros.Length; j++)
                {
                    if (numeros[i] > numeros[j])
                    {
                        aux = numeros[i];
                        numeros[i] = numeros[j];
                        numeros[j] = aux;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            //int dato = Integer.parseInt(JOptionPane.showInputDialog(this, "CANTIDAD DE ELEMENTOS"));
            int dato=int.Parse(Interaction.InputBox("DATO", "INGRESAR DATOS"));
            numeros = new int[dato];
            indice = 0;
            Agregar();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            txaMostrar.Clear();
            Mostrar();
        }

        private void btnOrdenarAsc_Click(object sender, EventArgs e)
        {
            InsercionAsc();
            MessageBox.Show(this, "SE ORDENO ASCENDENTEMENTE",
                    "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txaMostrar.Clear();
        }

        private void btnBurbujaAsc_Click(object sender, EventArgs e)
        {
            BurbujaAsc();
            MessageBox.Show(this, "SE ORDENO ASCENDENTEMENTE",
                    "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txaMostrar.Clear();
        }
    }
}
