/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usmp.aedi.semana9;

/**
 *
 * @author Alumno
 */
public class Triangulo 
{
    private double ladoA;
    private double ladoB;
    private double ladoC;
    private double angulo;

    public Triangulo() {}
    public Triangulo(double a, double b, double c, double ang)
    {
            this.ladoA=a;
            this.ladoB=b;
            this.ladoC=c;
            this.angulo=ang;
    }

    public double getLadoA() {
        return ladoA;
    }

    public double getLadoB() {
        return ladoB;
    }

    public double getLadoC() {
        return ladoC;
    }

    public double getAngulo() {
        return angulo;
    }

    public boolean esTriangulo()
    {
            boolean xOK=false;
            double a=this.ladoA;
            double b=this.ladoB;
            double c=this.ladoC;
            if(a+b>c&&a+c>b&&b+c>a)
                    xOK=true;
            return xOK;
    }
    
    public boolean es_equilatero()
    {
            boolean valor=false;
            if (this.ladoA==this.ladoB && this.ladoB==this.ladoC)
                    valor=true;

            return valor;
    }	

    public boolean es_escaleno()
    {
            boolean valor=false;
            if (this.ladoA!=this.ladoB && this.ladoB!=this.ladoC)
                    valor=true;

            return valor;
    }

    public boolean es_isoceles()
    {
            boolean valor=false;
            if (this.ladoA!=this.ladoB && this.ladoB==this.ladoC)
                    valor=true;

            return valor;
    }

    public boolean es_rectangulo()
    {
            boolean valor=false;
            if (this.angulo==90)
                    valor=true;

            return valor;
    }

}
