/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usmp.aedi.semana9;

/**
 *
 * @author Alumno
 */
public class Esfera 
{
    private String nombre; 
    private double radio;

    public Esfera() {}

    public Esfera(String nom,double rad) 
    {
        this.nombre=nom;
        this.radio=rad;
    }

    public String getNombre() 
    {
        return this.nombre;
    }

    public double getRadio() 
    {
        return this.radio;
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
    }

    public void setRadio(double radio) 
    {
        this.radio = radio;
    }
    
    public double volumen()
    {
            return Math.round((4.0/3.0) * Math.PI * Math.pow(this.radio,3.0)*100.0)/100.0;	
    }	

    public double superficie()
    {
            return Math.round(4.0 * Math.PI * Math.pow(this.radio,2.0)*100.0)/100.0;	
    }
    
}
