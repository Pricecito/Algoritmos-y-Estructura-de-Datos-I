/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usmp.aedi.semana10;

/**
 *
 * @author Alumno
 */
public class Hija extends Padre
{
    private String carrera;
    
    public Hija() //MUCHO CUIDADO
    {
        this.carrera = "ING. INDUSTRIAL";
    }

    public Hija(String nombre,int edad,float sueldo,String carrera)
    {
        super(nombre,edad,sueldo);  // llamada al constructor Padre
        this.carrera = carrera;
    }
  
    public Hija(String nombre,String carrera) 
    {
        super(nombre);
        this.carrera = carrera;
    }
  
    public void setCarrera (String carrera)
    {
        this.carrera = carrera;
    }

    public String getCarrera ()
    {
        return carrera;
    }

    public String verMensaje()
    {
        return "OBJETO DE LA CLASE HIJA";
    }
}
