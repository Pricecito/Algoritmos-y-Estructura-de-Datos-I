/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usmp.aedi.semana10;

import javax.swing.JOptionPane;

/**
 *
 * @author Alumno
 */
public class Padre 
{
      protected String nombre;
      protected int edad;
      protected float sueldo;

      public Padre()
      {
          //JOptionPane.showMessageDialog(null,"CUIDADO CON EL CONSTRUCTOR","IMPORTANTE",JOptionPane.WARNING_MESSAGE);
          this.nombre = "XXX";
      }
      
      public Padre(String nom)
      {
          this.nombre=nom;
      }
      
      public Padre(String nombre, int edad, float sueldo)
      {
        this.nombre = nombre;
        this.edad = edad;
        this.sueldo = sueldo;
      }

      //metodos set
      public void setNombre(String nombre)
      {
            this.nombre = nombre;
      }

      public void setEdad(int edad)
      {
        if (edad >0)
          this.edad = edad;
      }

      public void setSueldo(float sueldo)
      {
        this.sueldo = sueldo;
      }

      //metodos get
      public String getNombre()
      {
        return nombre;
      }

      public int getEdad()
      {
        return edad;
      }

      public float getSueldo()
      {
          return sueldo;
      }

      public String verMensaje()
      {
          return "OBJETO DE LA CLASE PADRE";
      }
    
}
