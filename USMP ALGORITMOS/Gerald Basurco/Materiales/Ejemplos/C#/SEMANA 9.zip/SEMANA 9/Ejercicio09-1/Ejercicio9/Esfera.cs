﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio9
{
    class Esfera
    {
        private String nombre;
        private double radio;

        public Esfera() { }

        public Esfera(String nom, double rad)
        {
            this.nombre = nom;
            this.radio = rad;
        }

        public String getNombre()
        {
            return nombre;
        }

        public double getRadio()
        {
            return radio;
        }

        public void setNombre(String nombre)
        {
            this.nombre = nombre;
        }

        public void setRadio(double radio)
        {
            this.radio = radio;
        }

        public double volumen()
        {
            return Math.Round((4.0 / 3.0) * Math.PI * Math.Pow(this.radio, 3.0),2);
        }

        public double superficie()
        {
            return Math.Round(4.0 * Math.PI * Math.Pow(this.radio, 2.0),2);
        }
    }
}
