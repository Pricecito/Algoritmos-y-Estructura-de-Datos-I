﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            String nom = txtNom.Text;
            int rad = int.Parse(txtRad.Text);
            Esfera e1 = new Esfera(nom, rad);
            txaRes.Text=null;
            txaRes.AppendText("NOMBRE: " + e1.getNombre() + "\r");
            txaRes.AppendText("RADIO: " + e1.getRadio() + "\r");
            txaRes.AppendText("VOLUMEN: " + e1.volumen() + "\r");
            txaRes.AppendText("SUPERFICIE: " + e1.superficie() + "\r\r");

            Esfera e2 = new Esfera();
            //e2.nombre = "ESFERA 2";
            e2.setNombre("ESFERA 2");
            e2.setRadio(3.0);
            txaRes.AppendText("NOMBRE: " + e2.getNombre() + "\n");
            txaRes.AppendText("RADIO: " + e2.getRadio() + "\n");
            txaRes.AppendText("VOLUMEN: " + e2.volumen() + "\n");
            txaRes.AppendText("SUPERFICIE: " + e2.superficie());
        }
    }
}
