﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio9_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Mostrar(Triangulo f)
        {
            txaRes.Text=null;
            txaRes.AppendText("LADO A: " + f.getLadoA() + "\n");
            txaRes.AppendText("LADO B: " + f.getLadoB() + "\n");
            txaRes.AppendText("LADO C: " + f.getLadoC() + "\n");
            txaRes.AppendText("ANGULO: " + f.getAngulo() + "\n");
            txaRes.AppendText("T. EQUILATERO: " + f.es_equilatero() + "\n");
            txaRes.AppendText("T. ESCALENO: " + f.es_escaleno() + "\n");
            txaRes.AppendText("T. ISOCELES: " + f.es_isoceles() + "\n");
            txaRes.AppendText("T. RECTANGULO: " + f.es_rectangulo() + "\n");
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            double lA = Double.Parse(txtLadoA.Text);
            double lB = Double.Parse(txtLadoB.Text);
            double lC = Double.Parse(txtLadoC.Text);
            double aN = Double.Parse(txtAng.Text);
            Triangulo t = new Triangulo(lA, lB, lC, aN);
            if (t.esTriangulo() == true)
                Mostrar(t);
            else
            {
                MessageBox.Show(this, "NO ES TRIANGULO",
                    "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLadoA.Text=null;
                txtLadoB.Text=null;
                txtLadoC.Text=null;
                txtAng.Text=null;
                txtLadoA.Focus();
            }
        }
    }
}
