﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio9_3
{
    public class Triangulo
    {
        private double ladoA;
        private double ladoB;
        private double ladoC;
        private double angulo;

        public Triangulo() { }
        public Triangulo(double a, double b, double c, double ang)
        {
            this.ladoA = a;
            this.ladoB = b;
            this.ladoC = c;
            this.angulo = ang;
        }

        public double getLadoA()
        {
            return ladoA;
        }

        public double getLadoB()
        {
            return ladoB;
        }

        public double getLadoC()
        {
            return ladoC;
        }

        public double getAngulo()
        {
            return angulo;
        }

        public bool esTriangulo()
        {
            bool xOK = false;
            double a = this.ladoA;
            double b = this.ladoB;
            double c = this.ladoC;
            if (a + b > c && a + c > b && b + c > a)
                xOK = true;
            return xOK;
        }

        public bool es_equilatero()
        {
            bool valor = false;
            if (this.ladoA == this.ladoB && this.ladoB == this.ladoC)
                valor = true;

            return valor;
        }

        public bool es_escaleno()
        {
            bool valor = false;
            if (this.ladoA != this.ladoB && this.ladoB != this.ladoC)
                valor = true;

            return valor;
        }

        public bool es_isoceles()
        {
            bool valor = false;
            if (this.ladoA != this.ladoB && this.ladoB == this.ladoC)
                valor = true;

            return valor;
        }

        public bool es_rectangulo()
        {
            bool valor = false;
            if (this.angulo == 90)
                valor = true;

            return valor;
        }
    }
}
