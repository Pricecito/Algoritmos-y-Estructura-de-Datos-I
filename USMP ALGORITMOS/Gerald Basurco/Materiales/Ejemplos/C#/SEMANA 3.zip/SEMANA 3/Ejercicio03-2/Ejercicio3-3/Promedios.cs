﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3_3
{
    public partial class Promedios : Form
    {
        double num1;
        double num2;
        double num3;
        public Promedios()
        {
            InitializeComponent();
        }

        public double numeroMenor(double n1, double n2, double n3)
        {
            double men;
            if (n1 < n2 && n1 < n3)
                men = n1;
            else
            {
                if (n2 < n1 && n2 < n3)
                    men = n2;
                else
                    men = n3;
            }
            return men;
        }

        public double numeroMayor(double n1, double n2, double n3)
        {
            double may;
            if (n1 > n2 && n1 > n3)
                may = n1;
            else
            {
                if (n2 > n1 && n2 > n3)
                    may = n2;
                else
                    may = n3;
            }
            return may;
        }

        public double redondear(double prom)
        {
            prom = Math.Round((num1 + num2 + num3) / 3,2);
            return prom;
        }


        private void btnCalcularPromedio_Click(object sender, EventArgs e)
        {
            double promedio,prom;
            num1 = Double.Parse(txtN1.Text);
            num2 = Double.Parse(txtN2.Text);
            num3 = Double.Parse(txtN3.Text);
            double menor = numeroMenor(num1, num2, num3);
            double mayor = numeroMayor(num1, num2, num3);
            if (menor == num1)
                num1 = mayor;
            else
            {
                if (menor == num2)
                    num2 = mayor;
                else
                    num3 = mayor;
            }
            promedio = ((num1 + num2 + num3) / 3);
            prom = redondear(promedio);
            txtR.Text=Convert.ToString(prom);
        }
    }
}
