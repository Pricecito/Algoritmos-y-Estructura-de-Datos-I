﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3_2
{
    public partial class CuentaVocales : Form
    {
        String nombre;
        int cantidad;
        public CuentaVocales()
        {
            InitializeComponent();
        }

        public void contarVocales()
        {
            cantidad = 0;
            nombre = txtNombre.Text.ToLower();
            for (int x = 0; x < nombre.Length; x++)
            {
                if ((nombre[x] == 'a') || (nombre[x] == 'e') || (nombre[x] == 'i')
                        || (nombre[x] == 'o') || (nombre[x] == 'u'))
                { 
                    cantidad++; 
                }
            }
        }

        public void mostrarResultado()
        {
            contarVocales();
            txtCantidad.Text=Convert.ToString(cantidad);
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            mostrarResultado();
        }
    }
}
