﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Ejercicio4_1
{
    public partial class Form1 : Form
    {
        int[] vec;
        int indice;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            int dato;
            indice = 0;
            int tamaño = int.Parse(txtTam.Text);
            vec = new int[tamaño];
            for (int i = 0; i < vec.Length; i++)
            {
                dato = int.Parse(Interaction.InputBox("DATO","INGRESAR DATOS"));
                vec[i] = dato;
                indice++;
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            txtRes.Clear();
            for (int i = 0; i < indice; i++)
            {
                txtRes.AppendText(vec[i].ToString()+"\r\n");
            }
        }
    }
}
