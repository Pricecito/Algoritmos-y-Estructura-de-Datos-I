﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4
{
    public partial class Vector1 : Form
    {
        public Vector1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String[] nombres = { "Juan", "Maria", "Pedro", "Javier", "David" };
            txtRes.Text="";
            for (int i = 0; i < nombres.Length; i++)
            {
                txtRes.AppendText(i + " - " + nombres[i] + "\r\n");
            }
        }
    }
}
