﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4_0
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[] vec = new double[3];
            /*double n1 = Double.Parse(txtN1.Text);
            double n2 = Double.Parse(txtN2.Text);
            double n3 = Double.Parse(txtN3.Text);

            vec[0] = n1;
            vec[1] = n2;
            vec[2] = n3;*/

            vec[0] = Double.Parse(txtN1.Text);
            vec[1] = Double.Parse(txtN2.Text);
            vec[2] = Double.Parse(txtN3.Text);

            double prom = (vec[0] + vec[1] + vec[2]) / 3;

            txtProm.Text=Math.Round(prom,2).ToString();
        }
    }
}
