﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4_3
{
    public partial class Form1 : Form
    {
        int[] numeros;
        int indice;
        int posicion;
        public Form1()
        {
            InitializeComponent();
            numeros = new int[4];
            indice = 0;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (indice < numeros.Length)
            {
                numeros[indice] = int.Parse(txtNum.Text);
                indice++;
                txtNum.Text=null;
                txtNum.Focus();
            }
            else
            {
                MessageBox.Show(this,"Vector lleno",
                                   "ADVERTENCIA", MessageBoxButtons.OK,
                                   MessageBoxIcon.Information);
                txtNum.Text=null;
            }

        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            txtMostrar.Text=null;
            for (int i = 0; i < numeros.Length; i++)
            {
                txtMostrar.AppendText("POS [" + i + "]--> " + numeros[i].ToString() + "\r\n");
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            int vbus, x = 0;
            vbus = int.Parse(txtBus.Text);
            for (int i = 0; i < numeros.Length; i++)
            {
                if (numeros[i] == vbus)
                {
                    MessageBox.Show(this, "Vaolor encontrado en la posición: " + i,
                                   "IMPORTANTE", MessageBoxButtons.OK,
                                   MessageBoxIcon.Exclamation);
                    posicion = i;
                    x = 1;
                }
            }

            if (x == 0)
                MessageBox.Show(this, "Vaolor NO ENCONTRADO",
                               "URGENTE", MessageBoxButtons.OK,
                               MessageBoxIcon.Error);

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            int vmod;
            vmod = int.Parse(txtMod.Text);
            numeros[posicion] = vmod;
            MessageBox.Show(this, "Valor MODIFICADO",
                                   "IMPORTANTE", MessageBoxButtons.OK,
                                   MessageBoxIcon.Information);
            txtBus.Text=null;
            txtMod.Text=null;
        }
    }
}
