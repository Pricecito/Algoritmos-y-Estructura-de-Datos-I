﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio4_2
{
    public partial class Form1 : Form
    {
        String[] nombres= new String[5];
        int indice=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void bntMostrar_Click(object sender, EventArgs e)
        {
            txtRes.Clear();
            for (int i = 0; i < indice; i++)
            {
                txtRes.AppendText(nombres[i]+"\r\n");
            }
        }

        private void bntAgregar_Click(object sender, EventArgs e)
        {
            if (indice < nombres.Length)
            {
                nombres[indice] = txtNom.Text;
                indice++;
                txtNom.Text = null;
                txtNom.Focus();
            }
            else
            {
                MessageBox.Show(this, "Vector lleno", "ADVERTENCIA", 
                    MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                txtNom.Text = null;
            }
        }
    }
}
