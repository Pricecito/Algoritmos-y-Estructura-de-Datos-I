﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio3
{
    public class Esfera
    {
        double radio;

        public Esfera(double rad)
        { 
            this.radio = rad; 
        }

        public Esfera(double ra, double x)
        {
            this.radio = ra + x;
        }


        public double volumen()
        {
            return Math.Round((4.0 / 3.0) * Math.PI * Math.Pow(this.radio, 3.0), 2);
        }

        public double superficie()
        {
            return Math.Round(4.0 * Math.PI * Math.Pow(this.radio, 2.0), 2);
        }
    }
}
