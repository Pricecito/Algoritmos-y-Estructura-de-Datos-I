﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    public partial class Interfaz : Form
    {
        public Interfaz()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double rad,vol,sup;
            rad = Double.Parse(txtRadio.Text);
            Esfera a = new Esfera(rad);
            vol = a.volumen();
            sup = a.superficie();
            txtVolA.Text = Convert.ToString(vol);
            txtSupA.Text = Convert.ToString(sup);

            Esfera b = new Esfera(rad, 1);
            vol = b.volumen();
            sup = b.superficie();
            txtVolB.Text = Convert.ToString(vol);
            txtSupB.Text = Convert.ToString(sup);
        }
    }
}










/*Esfera a = new Esfera(rad);
vol = a.volumen();
sup = a.superficie();
txtVolA.Text = Convert.ToString(vol);
txtSupA.Text = Convert.ToString(sup);

Esfera b = new Esfera(rad, 1.0);
vol = b.volumen();
sup = b.superficie();
txtVolB.Text = Convert.ToString(vol);
txtSupB.Text = Convert.ToString(sup);*/