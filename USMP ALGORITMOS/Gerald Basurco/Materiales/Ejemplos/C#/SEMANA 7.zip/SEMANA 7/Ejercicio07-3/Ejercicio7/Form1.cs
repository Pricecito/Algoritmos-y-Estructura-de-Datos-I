﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            //OBJETO a
            Persona a = new Persona();
            a.mostrarDatos();//Se invoca al metodo de instancia
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //OBJETO b
            Persona b = new Persona();
            b.nombre = "Juan";
            b.edad = 23;
            b.estatura = 1.85;
            b.mostrarDatos();//Se invoca al metodo de instancia
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //OBJETO c
            Persona c = new Persona("Pedro", 40, 1.74);
            c.mostrarDatos();//Se invoca al metodo de instancia
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //OBJETO d
            Persona d = new Persona("Dante");
            d.mostrarDatos();//Se invoca al metodo de instancia
        }

        private void button4_Click(object sender, EventArgs e)
        {

            //OBJETO f
            Persona f = new Persona("GLOBO", "Samuel", 37, 1.78);
            f.mostrarDatos();//Se invoca al metodo de instancia
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Persona.impMensaje();//Se invoca al metodo de clase
        }
    }
}
