﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3_1
{
    public partial class Interfaz : Form
    {
        public Interfaz()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double l1, l2, l3;
            l1 = Double.Parse(txtL1.Text);
            l2 = Double.Parse(txtL2.Text);
            l3 = Double.Parse(txtL3.Text);
            
            Triangulo t = new Triangulo(l1, l2, l3);

            if (t.esTriangulo())
            {
                txtR.Text="";
                txtR.AppendText(Convert.ToString("LADO 1: " + t.lado1) + "\r\n");
                txtR.AppendText(Convert.ToString("LADO 2: " + t.obtenerLado(2)) + "\r\n");
                txtR.AppendText(Convert.ToString("LADO 3: " + t.obtenerLado(3)) + "\r\n");
                t.calcularArea();
                txtR.AppendText(Convert.ToString("AREA: " + Math.Round(t.area,2)) + "\r\n");
                txtR.AppendText(Convert.ToString("PERIMETRO: " + t.obtenerPerimetro()) + "\r\n");
            }
            else
            {
                MessageBox.Show("No es un triangulo", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtL1.Text="";
                txtL2.Text = "";
                txtL3.Text = "";
                txtR.Text="";
            }
        }
    }
}
