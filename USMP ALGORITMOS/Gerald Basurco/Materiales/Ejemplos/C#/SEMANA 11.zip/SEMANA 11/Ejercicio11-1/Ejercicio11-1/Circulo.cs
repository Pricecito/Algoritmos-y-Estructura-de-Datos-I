﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_1
{
    public class Circulo : ObjetoGeometrico
    {
        private double radio;

        public Circulo(double r, String nom)
        {
            this.nombre = nom;
            this.radio = r;
        }

        public Circulo()
        {
            this.nombre = "XXXXXXX";
            this.radio = 1.0;
        }

        public double getRadio()
        {
            return radio;
        }

        public String getNombre()
        {
            return nombre;
        }

        public override double calcularArea()
        {
            return radio * radio + Math.PI;
        }

        public override double calcularPerimetro()
        {
            return 2 * Math.PI * radio;
        }
    }
}
