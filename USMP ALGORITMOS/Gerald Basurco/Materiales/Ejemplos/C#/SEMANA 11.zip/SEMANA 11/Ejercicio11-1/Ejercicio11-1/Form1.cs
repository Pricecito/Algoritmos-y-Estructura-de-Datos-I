﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio11_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void mostrarCirculo(Circulo c)
        {
            txaRes.AppendText("NOMBRE: " + c.getNombre() + "\n");
            txaRes.AppendText("RADIO: " + c.getRadio() + "\n");
            txaRes.AppendText("AREA: " + c.calcularArea() + "\n");
            txaRes.AppendText("PERIMETRO: " + c.calcularPerimetro() + "\n\n");
        }

        private void btnEjecutar_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Circulo c1 = new Circulo();
            mostrarCirculo(c1);
            Circulo c2 = new Circulo(2, "CIRCULO 2");
            mostrarCirculo(c2);
        }
    }
}
