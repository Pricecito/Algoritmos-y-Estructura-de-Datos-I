﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_1
{
    public abstract class ObjetoGeometrico
    {
        protected String nombre;

        public abstract double calcularArea();
        public abstract double calcularPerimetro();
    }
}

