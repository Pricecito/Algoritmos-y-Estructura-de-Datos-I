﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio11_3
{
    class Circulo : Figura,Dibujable
    {
        private double radio;

        public Circulo(String nombre, double radio) : base(nombre)
        {
            this.radio = radio;
        }

        public override double area()
        {
            return Math.PI * radio * radio;
        }

        public void dibujar(double x, double y)
        {
            MessageBox.Show("EN EL CIRCULO SE DIBUJO \nUN PUNTO EN (" + x + ", " + y + ")",
                   "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
