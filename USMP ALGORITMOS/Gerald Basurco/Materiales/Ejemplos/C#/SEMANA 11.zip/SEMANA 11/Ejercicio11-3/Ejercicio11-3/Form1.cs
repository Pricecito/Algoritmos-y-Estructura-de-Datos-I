﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio11_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Mostrar(Figura x)
        { 
            txaRes.AppendText("AREA DEL " + x.getNombre() + " ES :" + x.area() + "\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Circulo c = new Circulo("CIRCULO", 5.5);
            Mostrar(c);
            Mostrar(new Circulo("CIRCULO", 2.3));

            Mostrar(new Cuadrado("CUADRADO", 2.0));
            Figura f = new Cuadrado("CUADRADO", 6.0);
            Mostrar(f);
        }

        private void btnRotar_Click(object sender, EventArgs e)
        {
            Cuadrado r = new Cuadrado("CIRCULO", 3.0);
            r.rotar(45);
        }

        private void btnDibujar_Click(object sender, EventArgs e)
        {
            Circulo xx = new Circulo("CIRCULO", 5.5);
            xx.dibujar(5, 6);
            //new Circulo("CIRCULO", 5.5).dibujar(5, 6);
            new Cuadrado("CUADRADO", 2.0).dibujar(2, 3);
        }
    }
}
