﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_3
{
    interface Dibujable
    {
        public abstract void dibujar(double x, double y);
    }
}
