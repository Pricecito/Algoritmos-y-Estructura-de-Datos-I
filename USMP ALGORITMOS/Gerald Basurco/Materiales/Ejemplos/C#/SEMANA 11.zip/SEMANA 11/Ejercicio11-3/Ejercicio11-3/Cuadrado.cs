﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio11_3
{
    class Cuadrado : Figura,Rotable,Dibujable
    {
        private double lado;
        public Cuadrado(String nombre, double lado):base(nombre)
        {
            this.lado = lado;
        }

        public override double area()
        { 
            return lado * lado;
        }

        public void rotar(double x)
        {
            MessageBox.Show("EL CUADRADO ROTO " + x + " GRADOS",
                   "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void dibujar(double x, double y)
        {
            MessageBox.Show("EN EL CUADRADO SE DIBUJO \nUN PUNTO EN (" + x + "," + y + ")",
                   "IMPORTANTE", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
