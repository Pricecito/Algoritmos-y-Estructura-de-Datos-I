﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_3
{
    interface Rotable
    {
        public abstract void rotar(double grados);
    }
}
