﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ejercicio11_2
{
    public class Circulo : FiguraGeometrica
    {
        public double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }

        public Circulo(String nombre, double radio) : base(nombre)
        {
            this.radio = radio;
        }
        
        public override double area()
        {
            return Math.PI * radio * radio;
        }
    }
}
