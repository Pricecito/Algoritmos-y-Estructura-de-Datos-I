﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_2
{
    public class Cuadrado : FiguraGeometrica
    {
        private double lado;

        public Cuadrado(double lado)
        {
            this.lado = lado;
        }

        public Cuadrado(String nombre, double lado):base(nombre)
        {
            this.lado = lado;
        }

        public override double area()
        {
            return Math.Pow(this.lado, 2);
        }
    }
}
