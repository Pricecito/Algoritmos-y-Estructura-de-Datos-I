﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Ejercicio11_2
{
    public abstract class FiguraGeometrica
    {
        protected String nombre;

        public FiguraGeometrica()
        {
            this.nombre = Interaction.InputBox("INGRESAR NOMBRE", 
                "INGRESAR");
        }

        public FiguraGeometrica(String nombre)
        {
            this.nombre = nombre;
        }

        public String getNombre()
        {
            return this.nombre;
        }

        public abstract double area();
    }
}
