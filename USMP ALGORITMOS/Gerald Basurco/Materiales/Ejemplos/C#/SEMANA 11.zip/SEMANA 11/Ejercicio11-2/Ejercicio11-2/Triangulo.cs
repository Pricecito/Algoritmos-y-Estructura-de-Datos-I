﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio11_2
{
    public class Triangulo : FiguraGeometrica
    {
        private double bas;
        private double altura;

        public Triangulo(double bas, double altura)
        {
            this.bas = bas;
            this.altura = altura;
        }

        public Triangulo(String nombre, double bas, double altura):base(nombre)
        {
            this.bas = bas;
            this.altura = altura;
        }

        public override double area()
        {
            return (this.bas * this.altura)/2;
        }
    }
}
