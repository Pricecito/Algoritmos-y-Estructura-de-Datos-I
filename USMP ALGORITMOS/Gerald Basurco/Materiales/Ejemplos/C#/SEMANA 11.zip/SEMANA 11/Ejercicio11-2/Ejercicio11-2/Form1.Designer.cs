﻿
namespace Ejercicio11_2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txaRes = new System.Windows.Forms.RichTextBox();
            this.btnCuadrado = new System.Windows.Forms.Button();
            this.btnTriangulo = new System.Windows.Forms.Button();
            this.btnCirculo = new System.Windows.Forms.Button();
            this.btnAreas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txaRes
            // 
            this.txaRes.Location = new System.Drawing.Point(12, 12);
            this.txaRes.Name = "txaRes";
            this.txaRes.Size = new System.Drawing.Size(262, 125);
            this.txaRes.TabIndex = 0;
            this.txaRes.Text = "";
            // 
            // btnCuadrado
            // 
            this.btnCuadrado.Location = new System.Drawing.Point(280, 12);
            this.btnCuadrado.Name = "btnCuadrado";
            this.btnCuadrado.Size = new System.Drawing.Size(109, 23);
            this.btnCuadrado.TabIndex = 1;
            this.btnCuadrado.Text = "CUADRADO";
            this.btnCuadrado.UseVisualStyleBackColor = true;
            this.btnCuadrado.Click += new System.EventHandler(this.btnCuadrado_Click);
            // 
            // btnTriangulo
            // 
            this.btnTriangulo.Location = new System.Drawing.Point(280, 41);
            this.btnTriangulo.Name = "btnTriangulo";
            this.btnTriangulo.Size = new System.Drawing.Size(109, 23);
            this.btnTriangulo.TabIndex = 2;
            this.btnTriangulo.Text = "TRIANGULO";
            this.btnTriangulo.UseVisualStyleBackColor = true;
            this.btnTriangulo.Click += new System.EventHandler(this.btnTriangulo_Click);
            // 
            // btnCirculo
            // 
            this.btnCirculo.Location = new System.Drawing.Point(281, 71);
            this.btnCirculo.Name = "btnCirculo";
            this.btnCirculo.Size = new System.Drawing.Size(108, 23);
            this.btnCirculo.TabIndex = 3;
            this.btnCirculo.Text = "CIRCULO";
            this.btnCirculo.UseVisualStyleBackColor = true;
            this.btnCirculo.Click += new System.EventHandler(this.btnCirculo_Click);
            // 
            // btnAreas
            // 
            this.btnAreas.Location = new System.Drawing.Point(283, 114);
            this.btnAreas.Name = "btnAreas";
            this.btnAreas.Size = new System.Drawing.Size(104, 23);
            this.btnAreas.TabIndex = 4;
            this.btnAreas.Text = "AREAS";
            this.btnAreas.UseVisualStyleBackColor = true;
            this.btnAreas.Click += new System.EventHandler(this.btnAreas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 149);
            this.Controls.Add(this.btnAreas);
            this.Controls.Add(this.btnCirculo);
            this.Controls.Add(this.btnTriangulo);
            this.Controls.Add(this.btnCuadrado);
            this.Controls.Add(this.txaRes);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ejercicio11-2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txaRes;
        private System.Windows.Forms.Button btnCuadrado;
        private System.Windows.Forms.Button btnTriangulo;
        private System.Windows.Forms.Button btnCirculo;
        private System.Windows.Forms.Button btnAreas;
    }
}

