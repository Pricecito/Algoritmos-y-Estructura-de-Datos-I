﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio11_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void mostrar(FiguraGeometrica x)
        {
            txaRes.AppendText("NOMBRE: " + x.getNombre() + "\n");
            txaRes.AppendText("AREA: " + x.area() + "\n");
        }

        public FiguraGeometrica FigMayor(FiguraGeometrica[] fig)
        {
            FiguraGeometrica mayor = null;
            for (int i = 0; i < fig.Length; i++)
            {
                if (i == 0)
                    mayor = fig[i];
                else if (fig[i].area() > mayor.area())
                    mayor = fig[i];
            }
            return mayor;
        }

        private void btnCuadrado_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            Cuadrado cu = new Cuadrado(5);
            mostrar(cu);
        }

        private void btnTriangulo_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            //Triangulo tr=new Triangulo(10,5);
            //mostrar(tr);
            mostrar(new Triangulo(10, 5));
        }

        private void btnCirculo_Click(object sender, EventArgs e)
        {
            txaRes.Clear();
            //Circulo ci=new Circulo(1);
            //Circulo ci = new Circulo("JUAN",3);
            FiguraGeometrica ci = new Circulo(1);
            mostrar(ci);
        }

        private void btnAreas_Click(object sender, EventArgs e)
        {
            FiguraGeometrica[] fig = new FiguraGeometrica[3];
            fig[0] = new Cuadrado("CUADRADO", 4);
            fig[1] = new Circulo("CIRCULO", 2);
            fig[2] = new Triangulo("TRIANGULO", 8, 5);
            FiguraGeometrica fmayor = FigMayor(fig);
            txaRes.Clear();
            for (int i = 0; i < fig.Length; i++)
            {
                mostrar(fig[i]);
            }
            txaRes.AppendText("AREA MAYOR ES DE " + fmayor.getNombre() + " ---> " + fmayor.area());
        }
    }
}
